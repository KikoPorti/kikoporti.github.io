GITHUB PAGES — FRANCISCO PORTILLO

1. Upload index.html and style.css to the root of your GitHub Pages repository.
2. Upload your portrait as photo.jpg to the same root folder (optional; the site shows a clean FP placeholder if absent).
3. Upload FranciscoPortillo_CV.pdf if you want the CV buttons to work.
4. Commit the changes. GitHub Pages should rebuild automatically.

This version removes the old research-trajectory line and the Denia caption, keeps the portrait deliberately small, and uses a restrained Stanford-inspired academic palette (cardinal red, white, charcoal) with Source Serif 4 + Inter.
